import React from 'react';
export default function Portals(){return(<main><div className="container"><h1>Portals</h1><p>Client & Vendor demo portals (placeholder).</p></div></main>);}