import React from 'react';
import Link from 'next/link';

export default function Home() {
  return (
    <main>
      <div className="container hero">
        <h1>One team. Three divisions. Total resilience.</h1>
        <p>One-stop solutions: Facilities · Housing & Rehab · Mobile</p>
        <div className="cards">
          <div className="card">
            <h3>Facility Services</h3>
            <p>Janitorial · Day Porter · Floor Care · High Dusting · Post-Construction · Light Maintenance</p>
            <Link className="btn" href="/facility-services/">Get Quote</Link>
          </div>
          <div className="card">
            <h3>Resilient Homes & Rehab</h3>
            <p>Turns · Rehab · Painting · Flooring · Drywall · Vendor GC Network</p>
            <Link className="btn" href="/homes-rehab/">Request Estimate</Link>
          </div>
          <div className="card">
            <h3>Resilient Mobile</h3>
            <p>Fleet maintenance · On-site repairs · Diagnostics · Emergency response</p>
            <Link className="btn" href="/mobile/">Book Fleet Service</Link>
          </div>
        </div>
        <div>
          <span className="badge">Tampa</span>
          <span className="badge">Raleigh</span>
        </div>
      </div>
    </main>
  );
}
