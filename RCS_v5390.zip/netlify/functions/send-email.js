exports.handler = async () => {
  const to = process.env.LEADS_TO || 'resilient23.james@gmail.com';
  return { statusCode: 200, body: JSON.stringify({ ok: true, to }) };
};
