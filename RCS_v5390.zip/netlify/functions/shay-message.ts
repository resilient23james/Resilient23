import type { Handler } from '@netlify/functions';
export const handler: Handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: cors() };
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers: cors(), body: 'Method Not Allowed' };
  try {
    const body = JSON.parse(event.body || '{}') as { text?: string; locale?: 'en'|'es' };
    const reply = body.locale === 'es' ? 'Recibido. Nuestro equipo te contactará pronto.' : 'Received. Our team will follow up shortly.';
    return { statusCode: 200, headers: { ...cors(), 'Content-Type': 'application/json' }, body: JSON.stringify({ ok:true, reply }) };
  } catch {
    return { statusCode: 400, headers: cors(), body: 'Bad Request' };
  }
};
function cors(){ return {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type'}; }
