"use client";
import ShayAssistant from "./ShayAssistant";
export default function ShayMount(){ return <ShayAssistant/>; }
