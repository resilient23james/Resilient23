export const dynamic = 'force-static';
export default function Page(){
  return (
    <main>
      <h1>Thanks — we got your submission!</h1>
      <p className="lead">Our team will reach out shortly.</p>
    </main>
  );
}
