export const dynamic = 'force-static';
export default function Page(){
  return (
    <main>
      <h1>Resilient Commercial Solutions</h1>
      <p className="lead">Un equipo. Tres divisiones. Resiliencia total.</p>
    </main>
  );
}
