export const dynamic = 'force-static';
export default function Page(){
  return (
    <main>
      <h1>Resilient Commercial Solutions</h1>
      <p className="lead">One team. Three divisions. Total resilience.</p>
    </main>
  );
}
