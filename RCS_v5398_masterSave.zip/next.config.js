/** Next config */
module.exports = { output: 'export', reactStrictMode: true };
