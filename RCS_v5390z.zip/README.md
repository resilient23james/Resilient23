# RCS v5390z — Clean Deploy Shell

## Deploy on Netlify
1. Drag/drop this zip.
2. Set Environment Variables:
   - SENDGRID_API_KEY
   - LEADS_TO = resilient23.james@gmail.com
   - FROM_EMAIL = no-reply@resilientcommercialsolutions.com
   - (optional) SUPABASE_URL, SUPABASE_ANON_KEY
3. Build settings (auto from netlify.toml):
   - build: `npm run build`
   - publish: `.next`
   - functions: `netlify/functions`

## Test
- Submit any form → `{ ok: true }` and emails if key is set.
- Shay bubble EN/ES → contextual reply.
- `/portals` renders with Supabase stub text.
