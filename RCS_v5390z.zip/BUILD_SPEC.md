# BUILD_SPEC for RCS_v5390

- Base: RCS_v5379 (last known good).
- App Router only.
- Moved `styles/globals.css` -> `app/globals.css` and appended Shay CSS block.
- Updated `app/layout.tsx` and `app/es/layout.tsx` to import relative CSS and render `<ShayAssistant>`.
- Added `components/ShayAssistant.tsx` (client) that posts to `/.netlify/functions/shay-message`.
- Created `netlify/functions/shay-message.ts` with CORS and simple reply.
- Configs:
  - `next.config.js` export + unoptimized images
  - `tsconfig.json` strict + paths (`@/*`, `@components/*`, `@app/*`)
  - `package.json` deps (Next 14, React 18, @netlify/functions, @supabase/supabase-js) + TS devDeps.
  - `netlify.toml` publish `out/`, functions dir `netlify/functions`, esbuild bundler.
- Cleanup: removed colon-only lines and curly quotes in `app/**/page.tsx`.
- Assets: ensured `/public/Shay.jpg` plus existing favicon/assets unchanged.

## Success checks
- Netlify build `npm run build` -> `out/`.
- No `@styles` imports remain in layouts.
- Shay bubble appears on `/` and `/es`; function returns simple confirmation.
