'use client';
import React from 'react';

export default function PortalAuthForm(){
  return (
    <div className="portal-auth max-w-md mx-auto p-6 border rounded-md">
      <h2 className="text-xl font-semibold mb-2">Portal Login / Register</h2>
      <p className="text-sm text-gray-600 mb-4">Connect Supabase to enable login.</p>
      <form onSubmit={(e)=>e.preventDefault()}>
        <input className="w-full border p-2 mb-2" placeholder="Email" type="email" required/>
        <input className="w-full border p-2 mb-4" placeholder="Password" type="password" required/>
        <button className="w-full border p-2 rounded opacity-60 cursor-not-allowed" type="button" disabled>Submit</button>
      </form>
    </div>
  );
}
