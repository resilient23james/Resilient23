import React from 'react';

export default function Facility() {
  return (
    <main>
      <div className="container">
        <h1>Facility Services</h1>
        <p>Industries: Office · Medical · Industrial · Retail · Property Managers · Govt</p>
        <h2>Get Facility Quote</h2>
        <form className="form" method="post" action="/.netlify/functions/create-lead">
          <input type="hidden" name="division" value='facility'/>
          <div className="grid2">
            <input className="input" name="name" placeholder="Your Name" required/>
            <input className="input" name="email" placeholder="Email" type="email" required/>
          </div>
          <div className="grid2">
            <input className="input" name="company" placeholder="Company"/>
            <input className="input" name="phone" placeholder="Phone"/>
          </div>
          <input className='input' name='sqft' placeholder='Approx. square footage'/><input className='input' name='frequency' placeholder='Frequency (e.g., 5x/week)'/>
          <textarea className="textarea" name="details" placeholder="Project details" rows={5}></textarea>
          <input type="text" name="website" className="input" style={{display:'none'}} tabIndex={-1} autoComplete="off" />
          <button className="btn" type="submit">Submit</button>
        </form>
    
      </div>
    </main>
  );
}
