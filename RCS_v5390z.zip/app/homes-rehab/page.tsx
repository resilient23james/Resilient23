import React from 'react';

export default function HomesRehab() {
  return (
    <main>
      <div className="container">
        <h1>Resilient Homes & Rehab</h1>
        <p>Transitional Housing enablement with Revive Foundation partnerships.</p>
        <h2>Request Rehab Estimate</h2>
        <form className="form" method="post" action="/.netlify/functions/create-lead">
          <input type="hidden" name="division" value='homes-rehab'/>
          <div className="grid2">
            <input className="input" name="name" placeholder="Your Name" required/>
            <input className="input" name="email" placeholder="Email" type="email" required/>
          </div>
          <div className="grid2">
            <input className="input" name="company" placeholder="Company"/>
            <input className="input" name="phone" placeholder="Phone"/>
          </div>
          <input className='input' name='address' placeholder='Property address'/><input className='input' name='budget' placeholder='Budget (optional)'/>
          <textarea className="textarea" name="details" placeholder="Project details" rows={5}></textarea>
          <input type="text" name="website" className="input" style={{display:'none'}} tabIndex={-1} autoComplete="off" />
          <button className="btn" type="submit">Submit</button>
        </form>
    
      </div>
    </main>
  );
}
