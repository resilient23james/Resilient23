import React from 'react';

export default function ESHomes() {
  return (
    <main>
      <div className="container">
        <h1>Hogares & Rehabilitación</h1>
        <h2>Solicitar Estimado</h2>
        <form className="form" method="post" action="/.netlify/functions/create-lead">
          <input type="hidden" name="division" value='homes-rehab'/>
          <input type="hidden" name="language" value="es"/>
          <div className="grid2">
            <input className="input" name="name" placeholder="Su Nombre" required/>
            <input className="input" name="email" placeholder="Correo" type="email" required/>
          </div>
          <div className="grid2">
            <input className="input" name="company" placeholder="Empresa"/>
            <input className="input" name="phone" placeholder="Teléfono"/>
          </div>
          <textarea className="textarea" name="details" placeholder="Detalles del proyecto" rows={5}></textarea>
          <input type="text" name="sitio" className="input" style={{display:'none'}} tabIndex={-1} autoComplete="off" />
          <button className="btn" type="submit">Enviar</button>
        </form>
    
      </div>
    </main>
  );
}
