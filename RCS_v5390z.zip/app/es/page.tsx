import React from 'react';
import Link from 'next/link';

export default function HomeES() {
  return (
    <main>
      <div className="container hero">
        <h1>Un equipo. Tres divisiones. Resiliencia total.</h1>
        <p>Soluciones integrales: Instalaciones · Hogares & Rehab · Móvil</p>
        <div className="cards">
          <div className="card">
            <h3>Servicios de Instalaciones</h3>
            <p>Limpieza · Portería · Pisos · Alturas · Post-Obra · Mantenimiento ligero</p>
            <Link className="btn" href="/es/facility-services/">Solicitar Cotización</Link>
          </div>
          <div className="card">
            <h3>Hogares & Rehabilitación</h3>
            <p>Turnos · Rehab · Pintura · Pisos · Drywall · Red de Contratistas</p>
            <Link className="btn" href="/es/homes-rehab/">Solicitar Estimado</Link>
          </div>
          <div className="card">
            <h3>Móvil</h3>
            <p>Mantenimiento de flota · Reparaciones en sitio · Diagnósticos · Emergencias</p>
            <Link className="btn" href="/es/mobile/">Servicio de Flota</Link>
          </div>
        </div>
      </div>
    </main>
  );
}
