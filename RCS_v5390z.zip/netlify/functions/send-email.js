import sgMail from '@sendgrid/mail';

export const handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };
  const { to, from, subject, text, html } = JSON.parse(event.body || '{}');

  const leadTo = process.env.LEADS_TO || 'resilient23.james@gmail.com';
  const fromEmail = process.env.FROM_EMAIL || 'no-reply@resilientcommercialsolutions.com';
  const apiKey = process.env.SENDGRID_API_KEY || '';

  if (!apiKey) {
    // Graceful: don't crash, but report missing key
    return { statusCode: 200, body: JSON.stringify({ ok:false, error:'Missing SENDGRID_API_KEY' }) };
  }

  sgMail.setApiKey(apiKey);

  try {
    const adminMsg = {
      to: leadTo,
      from: fromEmail,
      subject: subject || 'New Website Lead',
      text: text || 'New lead received.',
      html: html || `<pre>${(text||'').replace(/</g,'&lt;')}</pre>`
    };
    const clientMsg = to ? {
      to,
      from: fromEmail,
      subject: 'Thanks for contacting Resilient',
      text: 'We received your message and will follow up shortly.',
      html: '<p>Thanks for contacting <strong>Resilient Commercial Solutions LLC</strong> — we received your message and will follow up shortly.</p>'
    } : null;

    const payloads = clientMsg ? [adminMsg, clientMsg] : [adminMsg];
    await sgMail.send(payloads);
    return { statusCode: 200, body: JSON.stringify({ ok:true }) };
  } catch (e) {
    return { statusCode: 200, body: JSON.stringify({ ok:false, error: e.message }) };
  }
};
