import type { Handler } from '@netlify/functions';

export const handler: Handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };
  let body:any = {};
  try { body = JSON.parse(event.body || '{}'); } catch(e){}
  const { message = '', locale = 'en' } = body;

  const trimmed = String(message).toLowerCase();
  let replyEn = 'Thanks for reaching out! How can Resilient help today?';
  if (trimmed.includes('quote') || trimmed.includes('estimate')) {
    replyEn = 'I can help with a fast quote. What facility type and approximate square footage?';
  } else if (trimmed.includes('vendor') || trimmed.includes('subcontractor')) {
    replyEn = 'Vendor onboarding: share your company name, service area, and COI status to get started.';
  } else if (trimmed.includes('contact') || trimmed.includes('email')) {
    replyEn = 'You can reach us at resilient23.james@gmail.com — or drop your details here and we will follow up.';
  }

  const replyEsMap:any = {
    base: '¡Gracias por escribir! ¿Cómo podemos ayudarte hoy?',
    quote: 'Puedo ayudar con una cotización rápida. ¿Qué tipo de instalación y metraje aproximado?',
    vendor: 'Onboarding de proveedores: envía nombre de empresa, zona y estado del COI para empezar.',
    contact: 'Puedes escribirnos a resilient23.james@gmail.com — o deja tus datos aquí y te contactamos.'
  };

  let reply = replyEn;
  if (locale === 'es') {
    if (trimmed.includes('cotiza') || trimmed.includes('presupuesto')) reply = replyEsMap.quote;
    else if (trimmed.includes('proveedor') || trimmed.includes('subcontratista')) reply = replyEsMap.vendor;
    else if (trimmed.includes('contacto') || trimmed.includes('correo')) reply = replyEsMap.contact;
    else reply = replyEsMap.base;
  }

  // Hook: optional log (no-op)
  try { /* insertLead stub */ } catch(e){}

  return { statusCode: 200, headers: { 'Content-Type':'application/json' }, body: JSON.stringify({ ok:true, reply }) };
};
