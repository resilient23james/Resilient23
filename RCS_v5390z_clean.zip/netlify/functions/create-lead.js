export const handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };

  let data = {};
  try { data = JSON.parse(event.body || '{}'); } catch(e){}
  const { name, email, phone, message, formType } = data;

  const errors = [];
  if (!name) errors.push('name');
  if (!email) errors.push('email');
  if (!message) errors.push('message');
  if (errors.length) return { statusCode: 400, body: JSON.stringify({ ok:false, error:'Missing fields', fields: errors }) };

  const subject = `New ${formType || 'Website'} Lead`;
  const text =
`Name: ${name}
Email: ${email}
Phone: ${phone || ''}
Type: ${formType || ''}
Message:
${message || ''}`;

  // call send-email function
  const host = (event.headers['x-forwarded-host'] || event.headers['host'] || '').replace(/\s/g,'');
  const proto = (event.headers['x-forwarded-proto'] || 'https');
  const base = host ? `${proto}://${host}` : (process.env.URL || '');
  let emailOk = false;
  try {
    const res = await fetch(`${base}/.netlify/functions/send-email`, {
      method: 'POST',
      headers: { 'Content-Type':'application/json' },
      body: JSON.stringify({ to: email, subject, text })
    });
    const j = await res.json().catch(()=>({}));
    emailOk = !j || j.ok !== false;
  } catch(e) { emailOk = false; }

  // Optional: stub for logging (no-op without keys)
  try {
    // insertLead stub – extend later for Supabase
  } catch(e){}

  return { statusCode: 200, headers: { 'Content-Type':'application/json' }, body: JSON.stringify({ ok:true, emailed: emailOk }) };
};
