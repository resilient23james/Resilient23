import './globals.css';
import ShayAssistant from '../components/ShayAssistant';
import React from 'react';
import Link from 'next/link';

export const metadata = {
  title: 'Resilient Commercial Solutions LLC',
  description: 'One team. Three divisions. Total resilience. Facility Services · Homes & Rehab · Mobile',
  openGraph: {
    title: 'Resilient Commercial Solutions LLC',
    description: 'One-stop solutions for Facilities, Housing & Rehab, and Mobile Fleet Services.',
    url: 'https://resilient23.netlify.app',
    siteName: 'Resilient Commercial Solutions',
    images: [{ url: '/logo_transparent.png', width: 800, height: 600, alt: 'Resilient Logo' }],
    locale: 'en_US',
    type: 'website'
  },
  icons: { icon: '/favicon.png' }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const orgSchema = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Resilient Commercial Solutions LLC',
    url: 'https://resilient23.netlify.app',
    logo: '/logo_transparent.png',
    contactPoint: [{ '@type': 'ContactPoint', telephone: '+1-813-486-8195', contactType: 'customer service', areaServed: 'US' }],
    department: [
      { '@type': 'Organization', name: 'Resilient Facility Services', serviceType: 'Facility Services' },
      { '@type': 'Organization', name: 'Resilient Homes & Rehab', serviceType: 'Housing Rehabilitation' },
      { '@type': 'Organization', name: 'Resilient Mobile', serviceType: 'Mobile Mechanics & Fleet' }
    ]
  };

  return (
    <html lang="en">
      <head>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(orgSchema) }} />
      </head>
      <body>
        <header>
          <div className="container" style={{display:'flex',alignItems:'center',gap:16}}>
            <img src="/logo.png" alt="Resilient" height={44}/>
            <nav style={{marginLeft:'auto',display:'flex',gap:14,flexWrap:'wrap'}}>
              <Link href="/">Home</Link>
              <Link href="/facility-services/">Facility Services</Link>
              <Link href="/homes-rehab/">Homes & Rehab</Link>
              <Link href="/mobile/">Mobile</Link>
              <Link href="/vendors/">Vendors</Link>
              <Link href="/portals/">Portals</Link>
              <Link href="/about/">About</Link>
              <Link href="/contact/">Contact</Link>
              <Link href="/es/">ES</Link>
            </nav>
          </div>
        </header>
        {children}
        <footer>
          <div className="container">
            <div>© {new Date().getFullYear()} Resilient Commercial Solutions LLC</div>
            <div className="footer-note">resilient23.james@gmail.com · (813) 486-8195</div>
          </div>
        </footer>
      </body>
    </html>
  );
}
