
'use client';
import React from 'react';

type Props = { locale?: 'en'|'es' };

export default function ShayAssistant({ locale='en' }: Props){
  const [open,setOpen]=React.useState(false);
  const [text,setText]=React.useState('');
  const [feed,setFeed]=React.useState<{from:'user'|'shay',text:string}[]>([]);
  async function send(e?:React.FormEvent){
    if(e) e.preventDefault();
    if(!text.trim()) return;
    const msg = text.trim();
    setFeed(f=>[...f,{from:'user',text:msg}]);
    setText('');
    try{
      const r = await fetch('/.netlify/functions/shay-message',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ text: msg, locale })
      });
      const data = await r.json().catch(()=>({reply:'OK'}));
      setFeed(f=>[...f,{from:'shay',text:(data && data.reply) || 'OK'}]);
    }catch{
      setFeed(f=>[...f,{from:'shay',text:'(offline)'}]);
    }
  }
  return (
    <>
      <button aria-label="Shay" className="shay-bubble" onClick={()=>setOpen(o=>!o)}>
        <div style={{width:24,height:24,borderRadius:6,background:'#e31c25'}} />
      </button>
      {open && (
        <div className="shay-panel">
          <div className="shay-header">
            <div className="shay-id"><div style={{width:16,height:16,borderRadius:4,background:'#e31c25'}} />Shay</div>
            <button onClick={()=>setOpen(false)} style={{background:'none',border:'none',color:'#fff',fontSize:18}}>×</button>
          </div>
          <div className="shay-feed">
            {feed.map((m,i)=>(<div key={i} className={'msg '+(m.from==='user'?'user':'shay')}>{m.text}</div>))}
          </div>
          <form className="shay-form" onSubmit={send}>
            <input value={text} onChange={e=>setText(e.target.value)} placeholder={locale==='es'?'Pregunta…':'Ask Shay…'} />
            <button type="submit">{locale==='es'?'Enviar':'Send'}</button>
          </form>
        </div>
      )}
    </>
  );
}
