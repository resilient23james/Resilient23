import React from 'react';
export default function Terms(){return(<main><div className="container"><h1>Terms of Service</h1><p>Placeholder terms.</p></div></main>);}