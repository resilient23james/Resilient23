import React from 'react';

export default function Mobile() {
  return (
    <main>
      <div className="container">
        <h1>Resilient Mobile</h1>
        <h2>Fleet/Repair Request</h2>
        <form className="form" method="post" action="/.netlify/functions/create-lead">
          <input type="hidden" name="division" value='mobile'/>
          <div className="grid2">
            <input className="input" name="name" placeholder="Your Name" required/>
            <input className="input" name="email" placeholder="Email" type="email" required/>
          </div>
          <div className="grid2">
            <input className="input" name="company" placeholder="Company"/>
            <input className="input" name="phone" placeholder="Phone"/>
          </div>
          <input className='input' name='fleet_count' placeholder='Fleet size (vehicles)'/><input className='input' name='urgency' placeholder='Urgency'/>
          <textarea className="textarea" name="details" placeholder="Project details" rows={5}></textarea>
          <input type="text" name="website" className="input" style={{display:'none'}} tabIndex={-1} autoComplete="off" />
          <button className="btn" type="submit">Submit</button>
        </form>
    
      </div>
    </main>
  );
}
