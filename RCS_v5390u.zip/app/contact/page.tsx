import React from 'react';
export default function Contact(){return(<main><div className="container"><h1>Contact</h1><p>Email: resilient23.james@gmail.com · Phone: (813) 486-8195</p></div></main>);}