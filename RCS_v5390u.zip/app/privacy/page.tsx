import React from 'react';
export default function Privacy(){return(<main><div className="container"><h1>Privacy Policy</h1><p>Placeholder policy.</p></div></main>);}