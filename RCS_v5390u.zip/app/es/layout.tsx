import '../globals.css';
import ShayAssistant from '../../components/ShayAssistant';
import React from 'react';
import Link from 'next/link';

export const metadata = {
  title: 'Resilient · ES',
  description: 'Un equipo. Tres divisiones. Resiliencia total.',
  openGraph: {
    title: 'Resilient Commercial Solutions LLC',
    description: 'Soluciones integrales: Instalaciones · Hogares & Rehab · Móvil',
    url: 'https://resilient23.netlify.app/es/',
    siteName: 'Resilient Commercial Solutions',
    images: [{ url: '/logo_transparent.png', width: 800, height: 600, alt: 'Logo Resilient' }],
    locale: 'es_US',
    type: 'website'
  },
  icons: { icon: '/favicon.png' }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const orgSchema = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Resilient Commercial Solutions LLC',
    url: 'https://resilient23.netlify.app/es/',
    logo: '/logo_transparent.png'
  };
  return (
    <html lang="es">
      <head>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(orgSchema) }} />
      </head>
      <body>
        <header>
          <div className="container" style={{display:'flex',alignItems:'center',gap:16}}>
            <img src="/logo.png" alt="Resilient" height={44}/>
            <nav style={{marginLeft:'auto',display:'flex',gap:14,flexWrap:'wrap'}}>
              <Link href="/es/">Inicio</Link>
              <Link href="/es/facility-services/">Instalaciones</Link>
              <Link href="/es/homes-rehab/">Hogares & Rehab</Link>
              <Link href="/es/mobile/">Móvil</Link>
              <Link href="/">EN</Link>
            </nav>
          </div>
        </header>
        {children}
        <footer>
          <div className="container">
            <div>© {new Date().getFullYear()} Resilient Commercial Solutions LLC</div>
            <div className="footer-note">resilient23.james@gmail.com · (813) 486-8195</div>
          </div>
        </footer>
      </body>
    </html>
  );
}
